package com.mx.santander.gp;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.context.IContext;

@RunWith(SpringRunner.class)
@SpringBootTest
public class GpNotificationAsyApplicationTests {
    private static final Logger LOGGER=LoggerFactory.getLogger(GpNotificationAsyApplicationTests.class);
    @Autowired
    private TemplateEngine templateEngine;
	@Test
	public void contextLoads() {
        IContext context = new Context();;
        context.getVariables().put("userName", "dave");
        String render = templateEngine.process("TEMPLATE_001", context);
        LOGGER.info(render);
	}

}
