package com.mx.santander.gp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GpNotificationAsyApplication {

	public static void main(String[] args) {
		SpringApplication.run(GpNotificationAsyApplication.class, args);
	}
}
