package com.mx.santander.gp.template.engine.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.spring4.SpringTemplateEngine;
import org.thymeleaf.templateresolver.TemplateResolver;

import com.mx.santander.gp.template.engine.resolver.MongoTemplateResolver;

@Configuration
public class TempleEngineConfig {
    /**
     * Se declara el resolutor de plantillas, y se estalblece el resolutor de las
     * recursos como {@link MongoTemplateResolver} para obetner las plantillas de BD
     * Mongo
     * 
     * @return {@link TemplateResolver}
     */
    @Bean
    public TemplateResolver templateResolver() {
        TemplateResolver resolver = new TemplateResolver();
        // Se establece MongoResolver para la busqueda de las plantillas en BD
        resolver.setResourceResolver(new MongoTemplateResolver());
        resolver.setTemplateMode("HTML5");
        resolver.setCharacterEncoding("UTF8");
        return resolver;
    }

    /**
     * Motor de tratamiento de plantillas HTML thymeleaf, se establece el
     * {@link TemplateResolver} de tipo {@link MongoTemplateResolver} para resolver
     * las plantillas de BD Mongo
     * 
     * @return {@link TemplateEngine}
     */
    @Bean
    public TemplateEngine templateEngine() {
        SpringTemplateEngine templateEngine = new SpringTemplateEngine();
        templateEngine.setTemplateResolver(templateResolver());
        return templateEngine;
    }
}
