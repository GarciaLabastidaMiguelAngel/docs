package com.mx.santander.gp.template.engine.resolver;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.thymeleaf.TemplateProcessingParameters;
import org.thymeleaf.resourceresolver.IResourceResolver;
import org.thymeleaf.util.Validate;

/**
 * Resolutor de plantillas a travez de Mongo, es necesario especificar el ID de
 * plantilla a cargar de la BD Mongo
 * 
 * @author Miguel Angel Garcia Labastida
 *
 */
public class MongoTemplateResolver implements IResourceResolver {
    /**
     * logger de clase
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(MongoTemplateResolver.class);

    public MongoTemplateResolver() {
        super();
    }

    public String getName() {
        return getClass().getName().toUpperCase();
    }

    @SuppressWarnings("deprecation")
    public InputStream getResourceAsStream(final TemplateProcessingParameters params, final String resourceName) {
        Validate.notNull(resourceName, "El id de plantilla no puede ser nulo");
        LOGGER.info("ID plantilla:{}", resourceName);
        LOGGER.debug("Se realiza la busqueda de la plantilla:{} en BD", resourceName);
        String template = "<div th:text=\"${userName}\">Some Username Here!</div>";
        return IOUtils.toInputStream(template);

    }
}
