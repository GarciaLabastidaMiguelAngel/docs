package com.authserver.oidc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OidcServerApplicationTests {

    @Test
    void contextLoads() {
        // Minimal smoke test - just verify Spring context loads
    }
}
