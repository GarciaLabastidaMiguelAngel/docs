package com.authserver.oidc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OidcServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(OidcServerApplication.class, args);
    }
}
